// Rating Bar 
function ratings() {
  var ratings = Number(document.getElementById("rating").value);
  if (1 <= ratings && ratings <= 3) {
      document.getElementById("value").innerHTML = `${ratings}`;
      document.getElementById("text").innerHTML = "Sorry for the inconveniece, please contact us as to how we could improve the experience";

  }
  else if (4 <= ratings && ratings <= 7) {
      document.getElementById("value").innerHTML = `${ratings}`;
      document.getElementById("text").innerHTML = "That's great to hear";

  }
  else {
      document.getElementById("value").innerHTML = `${ratings}`;
      document.getElementById("text").innerHTML = "Awesome!!";

  }
} 

// Image Swapping

function changeImage() 
{
  var image=document.getElementById("myImage");
  image.src="Nobita.png"; alt="" , width="150" , height="";
}

function resetImage() 
{
  var image=document.getElementById("myImage");
  image.src="Doraemon With dorayaki.png"; alt="" , width="150" , height="";
}

// Favourite Character

    function displayText() 
    {
      var text = document.getElementById("input").value;
      document.getElementById("output").textContent = text;
    }
  
// Game Thing

    var characters = [
      {
         
        name: "Doraemon",
        bio: "Some parts of Doraemon's backstory were consistent despite retcons. Matsushiba Robot Factory coded Doraemon MS-903 in 2112. An electrical bolt damaged him during production. He was trained to be a mechanical cat-like child sitter, but he's mediocre and obsolete." ,

      },
      {
        name: "Nobita",
        bio: "Nobita's a hero at best. He's a villain. Nobita napped after school, so he woke up late for school. Laziness keeps him up late and late for school. To Doraemon's dismay, Nobita begs for things. Nobita wants retribution, a better product than Suneo, and privileges."
      },
      {
        name: "Dorami",
        bio: "According to the 1989 short film Mini-Dora SOS!!, she loves Melon Bread and is afraid of cockroaches, but she shows no fear in the final panel of Urashima Candy. Dorami has 10,000 horse power to Doraemon's 129.3 and more advanced devices than him (such as Time Machine). She's smarter and better at manipulating electronics than her brother. She writes manga. Her boyfriend is Dora the Kid from The Doraemons."
      }
    ];

    function selectCharacter() 
    {
      var randomIndex = Math.floor(Math.random() * characters.length);
      var character = characters[randomIndex];
      document.getElementById("name").textContent = character.name;
      document.getElementById("bio").textContent = character.bio;
    }
